WMH Racing - RPM Apprentice Bootstrap / Recovery Updater
Target firmware: 1.055
Hardware: ESP32-S3 8MB

PURPOSE
This is for older RPM Apprentice units that need to be brought forward to the
BLE/app-supported firmware.

CUSTOMER REQUIREMENTS
- Windows 10/11 PC
- USB cable
- Internet connection the first time the updater is run

NO DEVELOPER SOFTWARE REQUIRED
The customer does NOT need Arduino IDE, PlatformIO, Python, or separate BIN files.

WHAT IT INSTALLS
- bootloader
- partition table
- OTA initialization data
- firmware 1.055
- LittleFS filesystem
- /logo.jpg

IMPORTANT
This is a factory/bootstrap flash. It overwrites saved RPM Apprentice settings.

HOW TO USE
1. Connect RPM Apprentice to the Windows PC with USB.
2. Run WMH-RPM-Apprentice-Bootstrap-1.055.exe.
3. Select the RPM Apprentice COM port.
4. Press Enter to begin.
5. Do not disconnect USB until SUCCESS is displayed.

If the updater cannot connect automatically:
1. Hold BOOT.
2. Press and release RESET.
3. Release BOOT.
4. Run the updater again.

The updater downloads the official Espressif esptool flashing engine on first use
and caches it under the user's Local AppData folder. Future runs reuse that copy.

EXE SHA-256:
4e9e28c2a8a7a0ef5628b8cfc03a941ccaa61453ea0a7beb644d1f8113cc22ba
